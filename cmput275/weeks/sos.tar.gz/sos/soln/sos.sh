#!/bin/bash
g++ sos.cpp -o sos -Wall && ./sos
rm -f ./sos

#include <iostream>
#include <algorithm> // for max()

using namespace std;

int main() {
  // declare variables

  // read the input

  // compute the answer

  // print the output

  return 0;
}

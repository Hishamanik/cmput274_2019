#!/bin/bash
g++ plateau.cpp -o plateau -Wall && ./plateau
rm -f ./plateau

#!/bin/bash
g++ falling.cpp -o falling -Wall && ./falling
rm -f ./falling

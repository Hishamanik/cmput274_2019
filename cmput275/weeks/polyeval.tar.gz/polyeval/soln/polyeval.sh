#!/bin/bash
g++ polyeval.cpp -o polyeval -Wall && ./polyeval
rm -f ./polyeval

#!/bin/bash
g++ numbers.cpp -o numbers -Wall -std=c++11 && ./numbers
rm -f ./numbers

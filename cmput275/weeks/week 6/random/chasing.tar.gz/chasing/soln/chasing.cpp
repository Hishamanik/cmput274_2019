#include <iostream>

using namespace std;

int main() {
  // declare variables

  // read the input

  // solve the problem

  // print the output

  return 0;
}

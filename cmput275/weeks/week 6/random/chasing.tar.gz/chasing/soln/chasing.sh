#!/bin/bash
g++ -std=c++11 chasing.cpp -o chasing -Wall && ./chasing
rm -f ./chasing

#include <iostream>
#include <cstring>

using namespace std;

int main() {
  // input contains the input string
  // n is the length of the input string
  char input[20001];
  int n = 0;

  // read in line and determine out how long it is
  cin >> input;
  n = strlen(input);

  // now solve the problem!

  return 0;
}
